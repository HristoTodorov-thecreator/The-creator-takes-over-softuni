from project.climbing_robot import ClimbingRobot
import unittest


class TestClimbingRobot(unittest.TestCase):

    def setUp(self):
        self.robot = ClimbingRobot('Mountain', 'Arm', 100, 50)

    def test_init_valid_data(self):
        self.assertEqual(self.robot.category, 'Mountain')
        self.assertEqual(self.robot.part_type, 'Arm')
        self.assertEqual(self.robot.capacity, 100)
        self.assertEqual(self.robot.memory, 50)
        self.assertEqual(self.robot.installed_software, [])

    def test_category_invalid_raises(self):
        with self.assertRaises(ValueError) as ex:
            ClimbingRobot('Invalid', 'Arm', 100, 50)
        self.assertEqual(str(ex.exception), f"Category should be one of {ClimbingRobot.ALLOWED_CATEGORIES}")

    def test_get_used_capacity_empty(self):
        result = self.robot.get_used_capacity()
        self.assertEqual(result, 0)

    def test_get_available_capacity_empty(self):
        result = self.robot.get_available_capacity()
        self.assertEqual(result, 100)

    def test_get_used_memory_empty(self):
        result = self.robot.get_used_memory()
        self.assertEqual(result, 0)

    def test_get_available_memory_empty(self):
        result = self.robot.get_available_memory()
        self.assertEqual(result, 50)

    def test_install_software_successful(self):
        software = {'name': 'ClimbPro', 'capacity_consumption': 30, 'memory_consumption': 20}
        result = self.robot.install_software(software)
        self.assertEqual(result, "Software 'ClimbPro' successfully installed on Mountain part.")
        self.assertEqual(len(self.robot.installed_software), 1)
        self.assertEqual(self.robot.installed_software[0]['name'], 'ClimbPro')

    def test_install_software_fail_capacity(self):
        software = {'name': 'HeavyApp', 'capacity_consumption': 150, 'memory_consumption': 10}
        result = self.robot.install_software(software)
        self.assertEqual(result, "Software 'HeavyApp' cannot be installed on Mountain part.")
        self.assertEqual(len(self.robot.installed_software), 0)

    def test_install_software_fail_memory(self):
        software = {'name': 'MemoryHog', 'capacity_consumption': 30, 'memory_consumption': 60}
        result = self.robot.install_software(software)
        self.assertEqual(result, "Software 'MemoryHog' cannot be installed on Mountain part.")
        self.assertEqual(len(self.robot.installed_software), 0)

    def test_install_software_fail_both(self):
        software = {'name': 'HeavyHog', 'capacity_consumption': 150, 'memory_consumption': 60}
        result = self.robot.install_software(software)
        self.assertEqual(result, "Software 'HeavyHog' cannot be installed on Mountain part.")
        self.assertEqual(len(self.robot.installed_software), 0)

    def test_install_multiple_software_successful(self):
        software1 = {'name': 'App1', 'capacity_consumption': 30, 'memory_consumption': 10}
        software2 = {'name': 'App2', 'capacity_consumption': 20, 'memory_consumption': 15}

        result1 = self.robot.install_software(software1)
        result2 = self.robot.install_software(software2)

        self.assertEqual(result1, "Software 'App1' successfully installed on Mountain part.")
        self.assertEqual(result2, "Software 'App2' successfully installed on Mountain part.")
        self.assertEqual(len(self.robot.installed_software), 2)
        self.assertEqual(self.robot.get_used_capacity(), 50)
        self.assertEqual(self.robot.get_used_memory(), 25)

    def test_install_software_exact_capacity_memory(self):
        software = {'name': 'ExactFit', 'capacity_consumption': 100, 'memory_consumption': 50}
        result = self.robot.install_software(software)
        self.assertEqual(result, "Software 'ExactFit' successfully installed on Mountain part.")
        self.assertEqual(len(self.robot.installed_software), 1)
        self.assertEqual(self.robot.get_available_capacity(), 0)
        self.assertEqual(self.robot.get_available_memory(), 0)

    def test_category_property_setter_valid(self):
        self.robot.category = 'Alpine'
        self.assertEqual(self.robot.category, 'Alpine')

    def test_category_property_setter_invalid(self):
        with self.assertRaises(ValueError) as ex:
            self.robot.category = 'Invalid'
        self.assertEqual(str(ex.exception), f"Category should be one of {ClimbingRobot.ALLOWED_CATEGORIES}")
        # Verify original category is unchanged
        self.assertEqual(self.robot.category, 'Mountain')

    def test_all_allowed_categories(self):
        for category in ClimbingRobot.ALLOWED_CATEGORIES:
            robot = ClimbingRobot(category, 'Arm', 100, 50)
            self.assertEqual(robot.category, category)


if __name__ == '__main__':
    unittest.main()