from project.gallery import Gallery

import unittest

class TestGallery(unittest.TestCase):

    def setUp(self):
        self.gallery = Gallery('ArtHouse1', 'Sofia', 250.5)

    def test_init(self):
        self.assertEqual(self.gallery.gallery_name, 'ArtHouse1')
        self.assertEqual(self.gallery.city, 'Sofia')
        self.assertEqual(self.gallery.area_sq_m, 250.5)
        self.assertTrue(self.gallery.open_to_public)
        self.assertEqual(self.gallery.exhibitions, {})

    def test_invalid_gallery_name_raises(self):
        with self.assertRaises(ValueError) as ve:
            Gallery('Art*House','Sofia',100)
        self.assertEqual(str(ve.exception),"Gallery name can contain letters and digits only!")

    def test_invalid_city_name_raises(self):
        with self.assertRaises(ValueError) as ve:
            Gallery('GalleryX','1Plovdiv',100)
        self.assertEqual(str(ve.exception),"City name must start with a letter!")

    def test_invalid_area_raises(self):
        with self.assertRaises(ValueError) as ve:
            Gallery('GalleryX','Plovdiv',0)
        self.assertEqual(str(ve.exception),"Gallery area must be a positive number!")

    def test_add_exhibition_successfully(self):
        result = self.gallery.add_exhibition('Modern Art',2021)
        self.assertEqual(result,'Exhibition "Modern Art" added for the year 2021.')
        self.assertEqual(self.gallery.exhibitions['Modern Art'],2021)

    def test_add_existing_exhibition(self):
        self.gallery.add_exhibition('Photography',2020)
        result = self.gallery.add_exhibition('Photography',2020)
        self.assertEqual(result,'Exhibition "Photography" already exists.')

    def test_remove_exhibition_successfully(self):
        self.gallery.add_exhibition('realism',2019)
        result = self.gallery.remove_exhibition('realism')
        self.assertEqual(result,'Exhibition "realism" removed.')
        self.assertNotIn('realism',self.gallery.exhibitions)

    def test_remove_non_existent(self):
        result = self.gallery.remove_exhibition('lol')
        self.assertEqual(result,'Exhibition "lol" not found.')

    def test_when_exhibition_is_closed(self):
        self.gallery.add_exhibition('Abstract',2002)
        self.gallery.open_to_public = False
        expected = "Gallery ArtHouse1 is currently closed for public! Check for updates later on."
        self.assertEqual(self.gallery.list_exhibitions(),expected)


    def test_list_exhibitions_when_open(self):
        self.gallery.add_exhibition("Renaissance", 2018)
        self.gallery.add_exhibition("Baroque", 2017)
        expected = "Renaissance: 2018\nBaroque: 2017"
        self.assertEqual(self.gallery.list_exhibitions(), expected)






if __name__ == '__main__':
    unittest.main()

