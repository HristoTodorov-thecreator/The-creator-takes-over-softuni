from project.furniture import Furniture
import unittest

class TestFurniture(unittest.TestCase):

    def setUp(self):
        self.furniture = Furniture('Modern Chair', 149.99, (800, 600, 400), True, 12.5)

    def test_valid_init(self):
        self.assertEqual(self.furniture.model, 'Modern Chair')
        self.assertEqual(self.furniture.price, 149.99)
        self.assertEqual(self.furniture.dimensions, (800, 600, 400))
        self.assertTrue(self.furniture.in_stock)
        self.assertEqual(self.furniture.weight, 12.5)

    def test_invalid_model_empty(self):
        with self.assertRaises(ValueError) as err:
            self.furniture.model = ""
        self.assertEqual(str(err.exception), "Model must be a non-empty string with a maximum length of 50 characters.")

    def test_invalid_model_too_long(self):
        with self.assertRaises(ValueError) as err:
            self.furniture.model = "X" * 51
        self.assertEqual(str(err.exception), "Model must be a non-empty string with a maximum length of 50 characters.")

    def test_negative_price(self):
        with self.assertRaises(ValueError) as err:
            self.furniture.price = -5
        self.assertEqual(str(err.exception), "Price must be a non-negative number.")

    def test_demensons_negative_value(self):
        with self.assertRaises(ValueError) as err:
            self.furniture.dimensions = (100, -200, 300)
        self.assertEqual(str(err.exception), "Dimensions tuple must contain integers greater than zero.")

    def test_invalid_dimensions_length(self):
        with self.assertRaises(ValueError) as err:
            self.furniture.dimensions = (100, 200)
        self.assertEqual(str(err.exception), "Dimensions tuple must contain 3 integers.")

    def test_valid_dimensions_change(self):
        new_dimensions = (900, 700, 500)
        self.furniture.dimensions = new_dimensions
        self.assertEqual(self.furniture.dimensions, new_dimensions)

    def test_valid_None(self):
        self.furniture.weight = None
        self.assertIsNone(self.furniture.weight)

    def test_invalid_weight_zero(self):
        with self.assertRaises(ValueError) as err:
            self.furniture.weight = 0.0
        self.assertEqual(str(err.exception), "Weight must be greater than zero.")

    def test_invalid_weight_negative(self):
        with self.assertRaises(ValueError) as err:
            self.furniture.weight = -10.0
        self.assertEqual(str(err.exception), "Weight must be greater than zero.")

    def test_get_available_status_in_stock(self):
        self.furniture.in_stock = True
        self.assertEqual(self.furniture.get_available_status(), "Model: Modern Chair is currently in stock.")

    def test_get_available_status_out_of_stock(self):
        self.furniture.in_stock = False
        self.assertEqual(self.furniture.get_available_status(), "Model: Modern Chair is currently unavailable.")

    def test_get_specifications_with_weight(self):
        spec = self.furniture.get_specifications()
        self.assertEqual(spec, "Model: Modern Chair has the following dimensions: 800mm x 600mm x 400mm and weighs: 12.5")

    def test_get_specifications_without_weight(self):
        self.furniture.weight = None
        spec = self.furniture.get_specifications()
        self.assertEqual(spec, "Model: Modern Chair has the following dimensions: 800mm x 600mm x 400mm and weighs: N/A")

if __name__ == "__main__":
    unittest.main()












