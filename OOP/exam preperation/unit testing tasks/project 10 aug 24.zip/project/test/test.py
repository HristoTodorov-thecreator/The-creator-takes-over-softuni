from project.soccer_player import SoccerPlayer

import unittest

class TestSoccerPlayer(unittest.TestCase):

    def setUp(self):
        self.player = SoccerPlayer('Cristiano Ronaldo',37,800,'Juventus')


    def test_init(self):
        self.assertEqual(self.player.name,'Cristiano Ronaldo')
        self.assertEqual(self.player.age,37)
        self.assertEqual(self.player.goals,800)
        self.assertEqual(self.player.team,'Juventus')
        self.assertEqual(self.player.achievements,{})

    def test_name_too_short_error(self):
        with self.assertRaises(ValueError) as ve:
            SoccerPlayer('Messi',35,750,'PSG')
        self.assertEqual(str(ve.exception),"Name should be more than 5 symbols!")

    def test_age_too_low_error(self):
        with self.assertRaises(ValueError) as ve:
            SoccerPlayer('Lamine Yamal',15,200,'Barcelona')
        self.assertEqual(str(ve.exception),"Players must be at least 16 years of age!")

    def test_goals_cannot_be_negative(self):
        player = SoccerPlayer('Mbappe',23,-10,'PSG')
        self.assertEqual(player.goals,0)

    def test_invalid_team_raises_error(self):
        with self.assertRaises(ValueError) as ve:
            SoccerPlayer('Benzema',20,300,'AL Hilal')
        self.assertEqual(str(ve.exception),"Team must be one of the following: Barcelona, Real Madrid, Manchester United, Juventus, PSG!")

    def test_team_change_successfully(self):
        result = self.player.change_team('PSG')
        self.assertEqual(result,"Team successfully changed!")
        self.assertEqual(self.player.team,'PSG')

    def test_change_team_invalid(self):
        result = self.player.change_team('CSKA')
        self.assertEqual(result,"Invalid team name!")
        self.assertEqual(self.player.team,'Juventus')

    def test_add_achievement(self):
        result = self.player.add_new_achievement("Ballon d'Or")
        self.assertEqual(result,"Ballon d'Or has been successfully added to the achievements collection!")
        self.assertEqual(self.player.achievements["Ballon d'Or"], 1)

    def test_add_new_achievement_multiple_times(self):
        self.player.add_new_achievement("Ballon d'Or")
        self.player.add_new_achievement("Ballon d'Or")
        self.assertEqual(self.player.achievements["Ballon d'Or"], 2)

    def test_less_than_operator_when_other_has_more_goals(self):
        other = SoccerPlayer('Lionel Messi',35,810,'PSG')
        result = self.player < other
        self.assertEqual(result, "Lionel Messi is a top goal scorer! S/he scored more than Cristiano Ronaldo.")

    def test_less_than_operator_when_self_has_more_goals(self):
        other = SoccerPlayer("Lionel Messi", 35, 700, "PSG")
        result = self.player < other
        self.assertEqual(result, "Cristiano Ronaldo is a better goal scorer than Lionel Messi.")




if __name__ == "__main__":
    unittest.main()

